<?php
/**
 * Simple GD-based Image Renderer for PDF417
 * Does not require intervention/image package
 * Uses native PHP GD library
 */

namespace Le\PDF417\Renderer;

use Le\PDF417\BarcodeData;

class GdImageRenderer extends AbstractRenderer
{
    protected array $options = [
        'format' => 'png',
        'scale' => 3,
        'ratio' => 3,
        'padding' => 10,
        'color' => [0, 0, 0],        // RGB black
        'bgColor' => [255, 255, 255], // RGB white
    ];

    public function validateOptions(): array
    {
        $errors = [];

        $format = $this->options['format'];
        if (!in_array($format, ['png', 'jpg', 'jpeg', 'gif'])) {
            $errors[] = "Invalid format: {$format}. Supported: png, jpg, gif";
        }

        $scale = $this->options['scale'];
        if (!is_numeric($scale) || $scale < 1 || $scale > 20) {
            $errors[] = "Invalid scale: {$scale}. Expected 1-20.";
        }

        $ratio = $this->options['ratio'];
        if (!is_numeric($ratio) || $ratio < 1 || $ratio > 10) {
            $errors[] = "Invalid ratio: {$ratio}. Expected 1-10.";
        }

        return $errors;
    }

    public function getContentType(): ?string
    {
        return match($this->options['format']) {
            'png' => 'image/png',
            'jpg', 'jpeg' => 'image/jpeg',
            'gif' => 'image/gif',
            default => 'image/png',
        };
    }

    /**
     * Render barcode as PNG image data
     */
    public function render(BarcodeData $data): string
    {
        $pixelGrid = $data->getPixelGrid();
        $height = count($pixelGrid);
        $width = count($pixelGrid[0]);

        // Extract options
        $scale = $this->options['scale'];
        $ratio = $this->options['ratio'];
        $padding = $this->options['padding'];
        $color = $this->options['color'];
        $bgColor = $this->options['bgColor'];

        // Calculate final dimensions
        $finalWidth = ($width * $scale) + (2 * $padding);
        $finalHeight = ($height * $scale * $ratio) + (2 * $padding);

        // Create image
        $image = imagecreatetruecolor($finalWidth, $finalHeight);

        // Allocate colors
        $bgColorAlloc = imagecolorallocate($image, $bgColor[0], $bgColor[1], $bgColor[2]);
        $fgColorAlloc = imagecolorallocate($image, $color[0], $color[1], $color[2]);

        // Fill background
        imagefill($image, 0, 0, $bgColorAlloc);

        // Draw barcode
        foreach ($pixelGrid as $y => $row) {
            foreach ($row as $x => $value) {
                if ($value) {
                    // Scale and apply ratio
                    $x1 = ($x * $scale) + $padding;
                    $y1 = ($y * $scale * $ratio) + $padding;
                    $x2 = $x1 + $scale - 1;
                    $y2 = $y1 + ($scale * $ratio) - 1;

                    imagefilledrectangle($image, $x1, $y1, $x2, $y2, $fgColorAlloc);
                }
            }
        }

        // Output to string
        ob_start();
        switch ($this->options['format']) {
            case 'jpg':
            case 'jpeg':
                imagejpeg($image, null, 90);
                break;
            case 'gif':
                imagegif($image);
                break;
            default:
                imagepng($image);
        }
        $imageData = ob_get_clean();

        imagedestroy($image);

        return $imageData;
    }

    /**
     * Render and save to file
     */
    public function renderToFile(BarcodeData $data, string $filepath): bool
    {
        $imageData = $this->render($data);
        return file_put_contents($filepath, $imageData) !== false;
    }
}
